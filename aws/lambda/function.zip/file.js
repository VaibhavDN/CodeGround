exports.handler = async (event, context) => {
  console.log(`Lambda started at ${new Date()}`);
};
